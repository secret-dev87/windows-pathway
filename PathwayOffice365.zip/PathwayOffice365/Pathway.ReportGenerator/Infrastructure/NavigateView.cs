﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pathway.ReportGenerator.Infrastructure {
    class NavigateView {
        public string PreviousSection { get; set; }
        public string PreviousWorkSheet { get; set; }
        public string NextSection { get; set; }
        public string NextWorkSheet { get; set; }

    }
}
