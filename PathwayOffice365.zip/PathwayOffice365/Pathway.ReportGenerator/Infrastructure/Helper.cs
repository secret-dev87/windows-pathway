﻿namespace Pathway.ReportGenerator.Infrastructure {
    internal static class Helper {
        public enum Color {
            Black = 1,
            White = 2,
            Red = 3,
            LightGray = 15,
            DarkGray = 16
        }
    }
}