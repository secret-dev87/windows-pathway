﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pathway.Core.Infrastructure {
	public class NewDataBaseColumn {
		public string TableName { get; set; }
		public string Query { get; set; }
		public string ColumnName { get; set; }
	}
}
