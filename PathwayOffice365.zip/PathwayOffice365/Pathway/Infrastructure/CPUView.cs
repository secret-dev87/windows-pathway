﻿namespace Pathway.Core.Infrastructure {
    public class CPUView {
        public string CPUNumber { get; set; }

        public long Value { get; set; }
        public long Value2 { get; set; }

        public double DoubleValue { get; set; }
    }
}
