﻿namespace Pathway.Core.Infrastructure.PerPathway {
    public class TransactionServerView {
        [System.ComponentModel.DefaultValue(0)]
        public double LinkmonToServer { get; set; }

        [System.ComponentModel.DefaultValue(0)]
        public double TcptoServer { get; set; }
    }
}