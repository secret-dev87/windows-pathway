﻿namespace Pathway.Core.Infrastructure.PerPathway.Term {
    public class TermUnusedView {
        public string Term { get; set; }
        public string Tcp { get; set; }
    }
}