﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pathway.Core.Infrastructure.PerPathway.Term {
    class TermView {
        public string Term { get; set; }
        public string Tcp { get; set; }
        public double Value { get; set; }
    }
}
