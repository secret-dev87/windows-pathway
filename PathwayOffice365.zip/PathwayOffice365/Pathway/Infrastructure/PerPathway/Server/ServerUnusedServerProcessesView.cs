﻿namespace Pathway.Core.Infrastructure.PerPathway.Server {
    public class ServerUnusedServerProcessesView {
        public string ServerClass { get; set; }
        public string Process { get; set; }
    }
}