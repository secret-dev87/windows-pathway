﻿namespace Pathway.Core.Infrastructure.PerPathway.Server {
    public class ServerUnusedServerClassView {
        public string ServerClass { get; set; }

        public long TermCount { get; set; }

        public long Unused { get; set; }
    }
}