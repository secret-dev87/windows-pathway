﻿namespace Pathway.Core.Infrastructure.PerPathway.Tcp {
    public class TcpUnusedView {
        public string Tcp { get; set; }
    }
}