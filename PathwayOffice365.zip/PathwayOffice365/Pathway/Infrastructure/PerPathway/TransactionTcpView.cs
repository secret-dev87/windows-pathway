﻿namespace Pathway.Core.Infrastructure.PerPathway {
    public class TransactionTcpView {
        [System.ComponentModel.DefaultValue(0)]
        public double TermToTcp { get; set; }
        [System.ComponentModel.DefaultValue(0)]
        public double TcpToServer { get; set; }
    }
}