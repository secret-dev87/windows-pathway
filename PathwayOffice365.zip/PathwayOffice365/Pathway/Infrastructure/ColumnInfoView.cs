﻿namespace Pathway.Core.Infrastructure {
    public class ColumnInfoView {
        public string ColumnName { get; set; }
        public string TestValue { get; set; }
        public string TypeName { get; set; }
        public int TypeValue { get; set; }
        public int ColumnOffSet { get; set; }
    }
}